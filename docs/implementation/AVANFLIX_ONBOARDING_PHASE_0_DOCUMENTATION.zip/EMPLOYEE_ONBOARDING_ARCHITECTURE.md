# AVANFlix Work Tracker — Employee Onboarding Architecture

**Module:** Employee Recruitment & Onboarding Lifecycle  
**Architecture Version:** 1.0.0 (Phase 0 Planning)  
**Author:** Senior Software Architect & HRMS Solution Architect  
**Status:** Architecture Draft for Review  

---

## 1. Executive Overview

The **AVANFlix Work Tracker** is currently an operational production system managing task assignment, client deliveries, shoot equipment checkouts, work logs, meetings, and team communications. This architectural blueprint defines the expansion of AVANFlix Work Tracker into a comprehensive **HR & Employee Lifecycle Management System** by introducing an end-to-end **Recruitment and Employee Onboarding Module**.

### Core Objectives
1. **Zero Disruption to Existing Operations:** Preserve all existing database schemas, API contracts, 3-role RBAC structures (`SUPER_ADMIN`, `ADMIN`, `EMPLOYEE`), and active workflows.
2. **End-to-End Candidate Journey:** Orchestrate the entire onboarding lifecycle from candidate initiation, tokenized application submission, document generation (Offer, Joining, NOC, NDA, Welcome), digital signature capture, verification, to employee provisioning.
3. **Automated Internal Workflow:** Automatically spawn trackable onboarding tasks in the existing Task management engine, assigning them to designated HR coordinators or department managers with real-time in-app and WhatsApp notifications.
4. **Deterministic & Secure Employee ID Generation:** Enforce the enterprise employee ID format (`D` + designation initial + `000` + 4 random digits, e.g. `DW0008449`) generated strictly upon final verification.
5. **Modern Storage & Infrastructure:** Integrate Cloudflare R2 for secure, encrypted document and image storage with presigned URLs, decoupling sensitive candidate PII from application servers.
6. **Strategic Database Evolution:** Establish the architectural foundation for a phased, zero-downtime migration from MongoDB to PostgreSQL via Prisma ORM.

---

## 2. High-Level System Architecture

```mermaid
flowchart TD
    subgraph "External Actors"
        Candidate["Candidate (External)"]
    end

    subgraph "Internal Actors"
        SuperAdmin["Super Admin"]
        OnboardingAssignee["Assigned Admin / Employee"]
    end

    subgraph "Next.js 16 Application Layer"
        CandidatePortal["Public Candidate Portal<br/>(/onboard/[token])"]
        DashboardOnboarding["Onboarding Management Screen<br/>(/dashboard/onboarding)"]
        OnboardAPI["Onboarding API Routes<br/>(/api/onboarding/*)"]
        TaskEngine["Existing Task Engine<br/>(taskService.ts)"]
        NotificationBridge["Notification Bridge<br/>(notificationService.ts)"]
        EmailService["Transactional Mailer<br/>(mailer.ts)"]
        DocGenerator["PDF Document Generator<br/>(pdfService.ts)"]
    end

    subgraph "Storage & Cloud Infrastructure"
        CloudflareR2["Cloudflare R2 Bucket<br/>(Private Encrypted Storage)"]
        PostgresDB[("Target: PostgreSQL Database<br/>(via Prisma ORM)")]
        MongoDB[("Current: MongoDB Database<br/>(Mongoose ORM)")]
    end

    SuperAdmin -->|1. Create Candidate| DashboardOnboarding
    DashboardOnboarding --> OnboardAPI
    OnboardAPI -->|2. Create Candidate Record| MongoDB
    OnboardAPI -->|3. Auto-spawn Task| TaskEngine
    OnboardAPI -->|4. Notify Assignee| NotificationBridge
    OnboardAPI -->|5. Dispatch Invite Email| EmailService

    EmailService -->|Secure Link with Token| Candidate
    Candidate -->|6. Submit Application & KYC| CandidatePortal
    CandidatePortal -->|7. Presigned Upload| CloudflareR2
    CandidatePortal -->|8. Save Application| OnboardAPI

    OnboardingAssignee -->|9. Review & Verify| DashboardOnboarding
    DashboardOnboarding -->|10. Approve Info| OnboardAPI
    OnboardAPI -->|11. Generate Offer & Joining Letters| DocGenerator
    DocGenerator -->|Upload Generated PDFs| CloudflareR2
    OnboardAPI -->|12. Dispatch Email 1 & Email 2| EmailService

    Candidate -->|13. Upload Signed NOC/NDA| CandidatePortal
    CandidatePortal -->|Upload Signed Documents| CloudflareR2

    OnboardingAssignee -->|14. Verify Signed Docs| DashboardOnboarding
    SuperAdmin -->|15. Final Approval| DashboardOnboarding
    OnboardAPI -->|16. Generate Employee ID & User Account| MongoDB
    OnboardAPI -->|17. Welcome Email + Post-Onboard Tasks| EmailService
    OnboardAPI -->|Post-Onboard Tasks| TaskEngine
```

---

## 3. Core Architectural Modules

### 3.1 Candidate Lifecycle Engine
- **Decoupled from User Table:** Candidates remain in a dedicated `Candidate` entity throughout recruitment. They do NOT exist in the `User` collection until final approval. This prevents phantom users, broken auth sessions, or incomplete profiles from polluting active directory endpoints.
- **State Machine Integrity:** The candidate progresses through strictly validated state transitions:
  `INVITED` $\rightarrow$ `APPLICATION_SUBMITTED` $\rightarrow$ `UNDER_REVIEW` $\rightarrow$ `CORRECTION_REQUESTED` $\rightarrow$ `OFFER_APPROVED` $\rightarrow$ `DOCUMENTS_PENDING` $\rightarrow$ `DOCUMENTS_SUBMITTED` $\rightarrow$ `DOCUMENTS_VERIFIED` $\rightarrow$ `COMPLETED` (or `REJECTED`).
- **Cryptographic Token Access:** Candidates authenticate exclusively through secure, high-entropy 256-bit cryptographic tokens embedded in single-use links (`/onboard/[token]`). Candidate access is bounded to their specific application record and expires based on configurable TTL.

### 3.2 Document Generation & Signature Verification
- **Dynamic PDF Generation:** Templated document generation engine creates customized PDFs for:
  1. *Offer Letter* (Compensation, employment type, reporting hierarchy, perks)
  2. *Joining Letter* (Official appointment confirmation, start date, orientation schedule)
  3. *Non-Disclosure Agreement (NDA)* (Proprietary media protection, AVANFlix client confidentiality)
  4. *No Objection Certificate (NOC) / Company Policies* (Equipment handling, safety compliance)
  5. *Welcome Letter* (Employee ID, credentials, team directory intro)
- **Two-Phase Email Distribution:**
  - *Email 1:* Offer Letter & Joining Letter dispatched upon application review approval.
  - *Email 2:* Separate subsequent transmission containing the NDA and NOC requiring wet or verified digital signatures.
- **Signed Document Verification:** The assigned coordinator reviews uploaded signed documents against physical standards before final authorization.

### 3.3 Task Management Bridge
- When a candidate is created, an onboarding workflow task is automatically registered in `Task` via `taskService.create()`:
  - **Assignee:** Designated Admin or authorized Employee.
  - **Title:** `Onboarding: [Candidate Full Name] — [Designation]`
  - **Priority:** `HIGH`
  - **Start Date:** Creation Date (Today)
  - **Deadline:** Proposed Joining Date
  - **Stage:** `CHECKLIST` with predefined milestones:
    - Review candidate KYC and bank documentation
    - Issue Offer & Joining letters
    - Follow up on signed NDA & NOC
    - Complete workstation, email, and asset allocation
    - Conduct Day-1 orientation
- **Notification Integration:** Uses `notificationService.create()` to immediately send an in-app alert and WhatsApp notification to the assigned staff member.

### 3.4 Cloudflare R2 Storage Integration
- **Zero Local Disk Dependency:** Eliminates local `/tmp` or public server storage for candidate PII.
- **Pre-signed Uploads:** Client browser requests an authorized pre-signed `PUT` URL from `/api/onboarding/upload-url`, uploading directly to Cloudflare R2 without routing heavy document payloads through the Next.js server.
- **Short-Lived Download Links:** Viewing sensitive documents (Aadhaar, PAN, Bank Proof, Signed NDA) requires an authenticated request generating a pre-signed `GET` URL valid for only 300 seconds (5 minutes).
- **Zero Attachment Policy:** Sensitive KYC and banking documents are NEVER attached directly to outbound emails to avoid exposure in transit and unencrypted mail server retention.

---

## 4. Employee ID Generation Engine

### Specification
- **Format:** `DW0008449`
- **Pattern:** `D` + Designation Initial + `000` + 4-digit numeric sequence.
- **Formula:**
  $$\text{Employee ID} = \text{"D"} + \text{char}_0(\text{Designation}) + \text{"000"} + \text{rand}(1000, 9999)$$
- **Examples:**
  - Web Developer $\rightarrow$ `DW0008449`
  - Designer $\rightarrow$ `DD0001234`
  - Accountant $\rightarrow$ `DA0005678`
  - Video Editor $\rightarrow$ `DV0009876`

### Collision Prevention & Uniqueness Guarantee
1. **Designation Initial Extraction:** Capitalized first letter of designation (skipping non-alphanumeric prefixes).
2. **Atomic Verification:** Before assigning the ID, an atomic check queries both active and historical user records.
3. **Collision Loop with Cap:** In the event of a random collision ($1 \text{ in } 9000$), the generator retries with a new random 4-digit seed up to 10 iterations.
4. **Database-Level Constraint:** Backed by an explicit database `UNIQUE` index constraint on `employeeId`.

---

## 5. Security, PII Protection & Legal Compliance

1. **Digital Personal Data Protection (DPDP) Act Compliance:**
   - Identity documents (Aadhaar, PAN) and banking records are classified as Sensitive Personal Data (SPD).
   - Only employees with explicitly assigned onboarding responsibilities or Super Admins can access candidate PII.
   - Bank account numbers and Aadhaar numbers are masked on the UI (e.g., `XXXX-XXXX-1234`).
2. **Access Scoping:**
   - Candidates cannot navigate to any dashboard route.
   - Employees assigned to onboarding cannot view candidate banking data unless granted explicit authorization.
3. **Audit Trail Immutability:**
   - All management actions (approvals, rejections, correction requests, document verifications, Super Admin overrides) are permanently recorded in `OnboardingAuditLog` with user ID, role, action, notes, and timestamp.

---

## 6. High-Level Migration Strategy

To support the transition from MongoDB to PostgreSQL:
1. **Target ORM:** Prisma ORM with PostgreSQL.
2. **Dual-Read Ready Architecture:** All new onboarding services will be authored with repository interfaces capable of targeting either Mongoose or Prisma adapters.
3. **Phase-0 Non-Breaking Invariant:** During Phase 0 and initial onboarding rollout, Mongoose models will interface with the candidate collections in MongoDB or an isolated PostgreSQL database without mutating existing user and task data.
