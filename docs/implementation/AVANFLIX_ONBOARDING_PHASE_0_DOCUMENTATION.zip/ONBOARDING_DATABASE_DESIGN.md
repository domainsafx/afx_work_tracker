# AVANFlix Work Tracker — Onboarding Database Design

**Module:** Employee Recruitment & Onboarding Module  
**Target Schema:** Relational PostgreSQL Schema (with Prisma ORM representation)  
**Status:** Approved Phase 0 Specification  

---

## 1. Entity-Relationship Overview

The recruitment and onboarding schema is designed as a secure, decoupled subsystem that links directly into the core `users` and `tasks` tables upon milestone triggers.

```mermaid
erDiagram
    USERS ||--o{ CANDIDATES : "assigned onboarding owner"
    USERS ||--o{ ONBOARDING_AUDIT_LOGS : "performed action"
    TASKS ||--o| CANDIDATES : "onboarding tracking task"
    CANDIDATES ||--|| CANDIDATE_IDENTITIES : "has identity & KYC"
    CANDIDATES ||--|| CANDIDATE_BANK_DETAILS : "has banking info"
    CANDIDATES ||--o{ ONBOARDING_DOCUMENTS : "generates & signs"
    CANDIDATES ||--o{ ONBOARDING_AUDIT_LOGS : "audit history"
    CANDIDATES ||--o| USERS : "promoted to employee"

    CANDIDATES {
        uuid id PK
        string first_name
        string last_name
        string email UK
        string mobile_number
        string designation
        string department
        enum employment_type "EMPLOYEE, INTERN_PAID, INTERN_UNPAID"
        decimal salary_or_stipend
        date proposed_joining_date
        enum status "INVITED, SUBMITTED, UNDER_REVIEW, CORRECTION_REQUESTED, OFFER_APPROVED, DOCS_PENDING, DOCS_SUBMITTED, DOCS_VERIFIED, COMPLETED, REJECTED"
        string application_token UK
        timestamp token_expires_at
        uuid assigned_to_id FK
        uuid onboarding_task_id FK
        string generated_employee_id UK
        uuid created_user_id FK
        timestamp created_at
        timestamp updated_at
    }

    CANDIDATE_IDENTITIES {
        uuid id PK
        uuid candidate_id FK, UK
        string aadhaar_number_encrypted
        string aadhaar_last_four
        string aadhaar_front_r2_key
        string aadhaar_back_r2_key
        string pan_number_encrypted
        string pan_front_r2_key
        string photo_r2_key
        boolean is_verified
        string verification_notes
        timestamp created_at
    }

    CANDIDATE_BANK_DETAILS {
        uuid id PK
        uuid candidate_id FK, UK
        string account_holder_name
        string account_number_encrypted
        string account_number_last_four
        string ifsc_code
        string bank_name
        string branch_name
        string proof_document_r2_key
        boolean is_verified
        timestamp created_at
    }

    ONBOARDING_DOCUMENTS {
        uuid id PK
        uuid candidate_id FK
        enum document_type "OFFER_LETTER, JOINING_LETTER, NOC, NDA, WELCOME_LETTER"
        string generated_pdf_r2_key
        string signed_pdf_r2_key
        enum status "GENERATED, SENT, SIGNED, VERIFIED, REJECTED"
        timestamp sent_at
        timestamp signed_at
        timestamp verified_at
        uuid verified_by_id FK
        string rejection_reason
    }

    ONBOARDING_AUDIT_LOGS {
        uuid id PK
        uuid candidate_id FK
        uuid actor_id FK
        string actor_role
        string action
        string previous_status
        string new_status
        text comments
        jsonb metadata
        timestamp created_at
    }
```

---

## 2. Table Specifications & Schema Definitions

### 2.1 Table: `candidates`
Stores candidate baseline information and manages lifecycle states.

```sql
CREATE TYPE employment_type_enum AS ENUM (
    'EMPLOYEE',
    'INTERN_PAID',
    'INTERN_UNPAID'
);

CREATE TYPE candidate_status_enum AS ENUM (
    'INVITED',
    'APPLICATION_SUBMITTED',
    'UNDER_REVIEW',
    'CORRECTION_REQUESTED',
    'OFFER_APPROVED',
    'DOCUMENTS_PENDING',
    'DOCUMENTS_SUBMITTED',
    'DOCUMENTS_VERIFIED',
    'COMPLETED',
    'REJECTED'
);

CREATE TABLE candidates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    mobile_number VARCHAR(20),
    date_of_birth DATE,
    residential_address TEXT,
    emergency_contact_name VARCHAR(100),
    emergency_contact_phone VARCHAR(20),
    emergency_contact_relation VARCHAR(50),
    
    designation VARCHAR(100) NOT NULL,
    department VARCHAR(100) NOT NULL,
    employment_type employment_type_enum NOT NULL DEFAULT 'EMPLOYEE',
    salary_or_stipend NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    proposed_joining_date DATE NOT NULL,
    
    status candidate_status_enum NOT NULL DEFAULT 'INVITED',
    application_token VARCHAR(255) NOT NULL UNIQUE,
    token_expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    
    assigned_to_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    onboarding_task_id UUID REFERENCES tasks(id) ON DELETE SET NULL,
    
    generated_employee_id VARCHAR(20) UNIQUE,
    created_user_id UUID UNIQUE REFERENCES users(id) ON DELETE SET NULL,
    
    rejection_reason TEXT,
    correction_notes TEXT,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_candidates_status ON candidates(status);
CREATE INDEX idx_candidates_assigned_to ON candidates(assigned_to_id);
CREATE INDEX idx_candidates_application_token ON candidates(application_token);
CREATE INDEX idx_candidates_generated_emp_id ON candidates(generated_employee_id);
```

---

### 2.2 Table: `candidate_identities`
Houses sensitive identification data (Aadhaar, PAN, Photographs) with encryption at rest and masked display fields.

```sql
CREATE TABLE candidate_identities (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    candidate_id UUID NOT NULL UNIQUE REFERENCES candidates(id) ON DELETE CASCADE,
    
    -- Encrypted at rest via AES-256-GCM application key
    aadhaar_number_encrypted TEXT NOT NULL,
    aadhaar_last_four CHAR(4) NOT NULL,
    aadhaar_front_r2_key VARCHAR(500) NOT NULL,
    aadhaar_back_r2_key VARCHAR(500) NOT NULL,
    
    pan_number_encrypted TEXT NOT NULL,
    pan_last_four CHAR(4) NOT NULL,
    pan_front_r2_key VARCHAR(500) NOT NULL,
    
    photo_r2_key VARCHAR(500) NOT NULL,
    
    is_verified BOOLEAN NOT NULL DEFAULT FALSE,
    verified_by_id UUID REFERENCES users(id) ON DELETE SET NULL,
    verified_at TIMESTAMP WITH TIME ZONE,
    verification_notes TEXT,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_candidate_identities_candidate ON candidate_identities(candidate_id);
```

---

### 2.3 Table: `candidate_bank_details`
Captures candidate banking information for payroll setup.

```sql
CREATE TABLE candidate_bank_details (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    candidate_id UUID NOT NULL UNIQUE REFERENCES candidates(id) ON DELETE CASCADE,
    
    account_holder_name VARCHAR(150) NOT NULL,
    -- Encrypted at rest
    account_number_encrypted TEXT NOT NULL,
    account_number_last_four VARCHAR(6) NOT NULL,
    
    ifsc_code VARCHAR(20) NOT NULL,
    bank_name VARCHAR(100) NOT NULL,
    branch_name VARCHAR(100) NOT NULL,
    
    proof_document_r2_key VARCHAR(500) NOT NULL,
    
    is_verified BOOLEAN NOT NULL DEFAULT FALSE,
    verified_by_id UUID REFERENCES users(id) ON DELETE SET NULL,
    verified_at TIMESTAMP WITH TIME ZONE,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_candidate_bank_candidate ON candidate_bank_details(candidate_id);
```

---

### 2.4 Table: `onboarding_documents`
Tracks all generated and signed legal agreements throughout the onboarding pipeline.

```sql
CREATE TYPE onboarding_doc_type_enum AS ENUM (
    'OFFER_LETTER',
    'JOINING_LETTER',
    'NOC',
    'NDA',
    'WELCOME_LETTER'
);

CREATE TYPE onboarding_doc_status_enum AS ENUM (
    'GENERATED',
    'SENT',
    'SIGNED',
    'VERIFIED',
    'REJECTED'
);

CREATE TABLE onboarding_documents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    candidate_id UUID NOT NULL REFERENCES candidates(id) ON DELETE CASCADE,
    document_type onboarding_doc_type_enum NOT NULL,
    
    generated_pdf_r2_key VARCHAR(500) NOT NULL,
    signed_pdf_r2_key VARCHAR(500),
    
    status onboarding_doc_status_enum NOT NULL DEFAULT 'GENERATED',
    sent_at TIMESTAMP WITH TIME ZONE,
    signed_at TIMESTAMP WITH TIME ZONE,
    verified_at TIMESTAMP WITH TIME ZONE,
    verified_by_id UUID REFERENCES users(id) ON DELETE SET NULL,
    
    rejection_reason TEXT,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(candidate_id, document_type)
);

CREATE INDEX idx_onboarding_docs_candidate ON onboarding_documents(candidate_id);
CREATE INDEX idx_onboarding_docs_type_status ON onboarding_documents(document_type, status);
```

---

### 2.5 Table: `onboarding_audit_logs`
Provides an immutable trail of every administrative override, approval, or rejection.

```sql
CREATE TABLE onboarding_audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    candidate_id UUID NOT NULL REFERENCES candidates(id) ON DELETE CASCADE,
    actor_id UUID REFERENCES users(id) ON DELETE SET NULL,
    actor_role VARCHAR(50) NOT NULL,
    action VARCHAR(100) NOT NULL,
    previous_status VARCHAR(50),
    new_status VARCHAR(50),
    comments TEXT,
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_onboarding_audit_candidate ON onboarding_audit_logs(candidate_id);
CREATE INDEX idx_onboarding_audit_actor ON onboarding_audit_logs(actor_id);
```

---

## 3. Data Encryption & Security Safeguards

1. **Envelope Encryption for Identification & Financial Data:**
   - Aadhaar numbers, PAN numbers, and Bank Account numbers are encrypted using AES-256-GCM before writing to the database.
   - Decryption keys are stored in environment variables (`PII_ENCRYPTION_KEY`), never checked into version control.
   - For UI rendering and search, non-sensitive unencrypted fields (`aadhaar_last_four`, `pan_last_four`, `account_number_last_four`) are stored separately.
2. **Deterministic Uniqueness on Employee ID:**
   - `candidates.generated_employee_id` and `users.employeeId` maintain an unambiguous `UNIQUE` index.
   - Generation algorithms check both tables simultaneously before persisting the record.
