# AVANFlix Work Tracker — MongoDB to PostgreSQL Migration Plan

**Project:** AVANFlix Work Tracker (`employee-work-tracker`)  
**Target Architecture:** PostgreSQL 16+ via Prisma ORM  
**Current Architecture:** MongoDB 8.x via Mongoose 8.7.0  
**Status:** Architectural Plan (Zero Code Changes in Phase 0)  

---

## 1. Executive Summary

This document specifies the end-to-end strategy for migrating the AVANFlix Work Tracker application from MongoDB/Mongoose to PostgreSQL/Prisma. The migration transitions the system from a document-oriented database to a relational, strongly-typed architecture to support complex HR workflows, strict ACID transactions, relational integrity, and enterprise auditability.

Strict Migration Principles:
1. **Zero Downtime:** Continuous system availability throughout data synchronization.
2. **Zero Data Loss:** Complete integrity verification and checksum matching between MongoDB collections and PostgreSQL tables.
3. **Rollback Safety:** Immediate fallback capability to MongoDB at every intermediate milestone.
4. **No Uncontrolled Dual-Writing:** Phased cutover via verified synchronization scripts rather than risky runtime dual-writes.

---

## 2. Existing MongoDB Collection Inventory

The existing application contains **21 Mongoose models and collections**:

| # | Collection / Model | Document Count / Purpose | Key Fields & Types | Relational Dependencies |
|---|---|---|---|---|
| 1 | `User` | Core employees & admins | `_id`, `name`, `firstName`, `lastName`, `employeeId`, `email`, `passwordHash`, `role`, `department`, `designation`, `joiningDate`, `isActive`, `availabilityStatus`, `leaveFrom`, `leaveTo`, `phone`, `whatsappOptIn` | Self-contained; referenced by all other models |
| 2 | `Task` | Work assignments & checklists | `_id`, `title`, `description`, `priority`, `department`, `assignedTo` (User), `createdBy` (User), `startDate`, `deadline`, `status`, `stage`, `completionPercent`, `stageLinks`, `timeline`, `delaySubmission` | Depends on `User` |
| 3 | `TaskUpdate` | Historical task audit log | `_id`, `task` (Task), `author` (User), `action`, `progressPercent`, `workDone`, `comment`, `reviewStatus`, `reviewedBy` (User) | Depends on `Task`, `User` |
| 4 | `TransferRequest` | Task reallocation workflows | `_id`, `task` (Task), `requestedBy` (User), `transferTo` (User), `reason`, `status`, `reviewedBy` (User) | Depends on `Task`, `User` |
| 5 | `WorkLog` | Daily employee logs | `_id`, `employee` (User), `date`, `summary`, `blockers`, `notes`, `submittedAt` | Depends on `User` |
| 6 | `LeaveRequest` | Employee leave applications | `_id`, `requestedBy` (User), `leaveFrom`, `leaveTo`, `leaveType`, `reason`, `status`, `reviewedBy` (User), `reviewedAt` | Depends on `User` |
| 7 | `Department` | Department lookup master | `_id`, `name`, `code`, `isActive` | Standalone |
| 8 | `Holiday` | Company holiday calendar | `_id`, `name`, `date`, `year`, `description` | Standalone |
| 9 | `Equipment` | Production & shoot inventory | `_id`, `name`, `category`, `code`, `totalQuantity`, `isActive`, `createdBy` (User) | Depends on `User` |
| 10 | `ShootLog` | Gear checkout/checkin logs | `_id`, `shootTitle`, `shootDate`, `location`, `takenBy` (User), `items` (embedded), `status` ("OUT"/"RETURNED"), `checkedOutAt`, `returnedAt` | Depends on `User`, `Equipment` |
| 11 | `Client` | Client CRM profiles & drive links | `_id`, `name`, `description`, `deckLink`, `deliverablesLink`, `contentLink`, `mouLink`, `isActive`, `createdBy` (User) | Depends on `User` |
| 12 | `DeliveryEvent` | Client delivery deadlines | `_id`, `client` (Client), `title`, `date`, `description`, `createdBy` (User) | Depends on `Client`, `User` |
| 13 | `Conversation` | 1:1 and group chats | `_id`, `type`, `participants` (User[]), `lastMessageAt`, `title` | Depends on `User` |
| 14 | `Message` | Chat messages | `_id`, `conversation` (Conversation), `sender` (User), `content`, `readBy` (User[]) | Depends on `Conversation`, `User` |
| 15 | `Call` | WebRTC call room records | `_id`, `type`, `callType`, `initiator` (User), `status`, `participants` (embedded), `startedAt`, `endedAt` | Depends on `User` |
| 16 | `CallSignal` | WebRTC signaling exchange | `_id`, `call` (Call), `from` (User), `to` (User), `type`, `payload` | Depends on `Call`, `User` |
| 17 | `Meeting` | Video/Voice meeting schedule | `_id`, `title`, `scheduledAt`, `host` (User), `participants` (User[]), `status` | Depends on `User` |
| 18 | `Notification` | In-app user notifications | `_id`, `recipient` (User), `title`, `message`, `type`, `relatedTask` (Task), `isRead` | Depends on `User`, `Task` |
| 19 | `PasswordResetOTP` | Password reset verification | `_id`, `email`, `otpHash`, `expiresAt` | Standalone |
| 20 | `AppSettings` | Global system configurations | `_id`, `leaveApprover` (User), `updatedAt` | Depends on `User` |
| 21 | `SystemLock` | Distributed cross-instance locks | `_id`, `key`, `lockedBy`, `lockedAt`, `lockedUntil` | Standalone |

---

## 3. Prisma ORM & PostgreSQL Technical Evaluation

### Compatibility with Current Stack
- **Next.js 16.2.10 (Turbopack):** Fully compatible with Prisma v5.x / v6.x. Prisma's client generation (`@prisma/client`) works seamlessly in Next.js Server Components, Server Actions, Route Handlers, and Edge Middleware proxies (via Prisma Accelerate or standard Node runtime).
- **React 19:** Zero friction; Prisma runs strictly in backend Server Actions and API handlers.
- **Node.js 26.5 & TypeScript 5.6:** Complete compatibility with TypeScript strict mode, providing end-to-end compile-time type safety.

### Relational Schema Design in PostgreSQL
Unlike MongoDB's embedded arrays (e.g. `Task.timeline`, `ShootLog.items`, `Call.participants`), PostgreSQL enforces first-class normalized relational tables:
1. `users`
2. `tasks`
3. `task_timeline_entries` (formerly embedded in `Task`)
4. `task_updates`
5. `task_delay_submissions`
6. `transfer_requests`
7. `work_logs`
8. `leave_requests`
9. `departments`
10. `holidays`
11. `equipment`
12. `shoot_logs`
13. `shoot_log_items` (formerly embedded in `ShootLog`)
14. `clients`
15. `delivery_events`
16. `conversations`
17. `conversation_participants` (many-to-many join)
18. `messages`
19. `message_read_receipts`
20. `calls`
21. `call_participants`
22. `call_signals`
23. `meetings`
24. `meeting_participants`
25. `notifications`
26. `password_reset_otps`
27. `app_settings`
28. `system_locks`

*(Plus new Onboarding tables: `candidates`, `candidate_identities`, `candidate_bank_details`, `onboarding_documents`, `onboarding_audit_logs`).*

---

## 4. Proposed Prisma Schema (Core Entity Definitions)

```prisma
datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

generator client {
  provider = "prisma-client-js"
}

enum Role {
  SUPER_ADMIN
  ADMIN
  EMPLOYEE
}

enum AvailabilityStatus {
  ACTIVE
  ON_LEAVE
  INACTIVE
}

enum TaskStatus {
  PENDING
  NOTICED
  IN_PROGRESS
  COMPLETED
  ISSUE
  DELAYED
  CANCELLED
}

enum TaskStage {
  CHECKLIST
  WIP
  WAITING_FOR_APPROVAL
  CHANGES_TO_BE_MADE
  SENT_TO_CLIENT
  FINALIZED
  CLOSED
}

model User {
  id                 String             @id @default(uuid())
  mongoId            String?            @unique // Preserved for data migration lineage
  name               String
  firstName          String?
  lastName           String?
  employeeId         String?            @unique
  email              String             @unique
  passwordHash       String
  role               Role               @default(EMPLOYEE)
  department         String?
  designation        String?
  joiningDate        DateTime?
  isActive           Boolean            @default(true)
  availabilityStatus AvailabilityStatus @default(ACTIVE)
  availability       String             @default("AVAILABLE")
  leaveFrom          DateTime?
  leaveTo            DateTime?
  leaveReason        String?
  phone              String?
  whatsappOptIn      Boolean            @default(true)
  createdAt          DateTime           @default(now())
  updatedAt          DateTime           @updatedAt

  // Relational mappings
  assignedTasks      Task[]             @relation("TaskAssignee")
  createdTasks       Task[]             @relation("TaskCreator")
  workLogs           WorkLog[]
  leaveRequests      LeaveRequest[]     @relation("LeaveRequester")
  reviewedLeaves     LeaveRequest[]     @relation("LeaveReviewer")
  shootLogs          ShootLog[]
  notifications      Notification[]
  assignedCandidates Candidate[]        @relation("CandidateOnboardingAssignee")

  @@index([email])
  @@index([employeeId])
  @@index([role])
}

model Task {
  id                      String       @id @default(uuid())
  mongoId                 String?      @unique
  title                   String
  description             String
  priority                String       @default("MEDIUM")
  department              String
  assignedToId            String
  assignedTo              User         @relation("TaskAssignee", fields: [assignedToId], references: [id])
  createdById             String
  createdBy               User         @relation("TaskCreator", fields: [createdById], references: [id])
  startDate               DateTime
  deadline                DateTime
  estimatedHours          Float?
  status                  TaskStatus   @default(PENDING)
  stage                   TaskStage    @default(CHECKLIST)
  completionPercent       Int          @default(0)
  stageLink               String?
  stageLinks              String[]     @default([])
  stageNote               String?
  timeSpentMinutes        Int          @default(0)
  estimatedCompletionDate DateTime?
  createdAt               DateTime     @default(now())
  updatedAt               DateTime     @updatedAt

  timeline                TaskTimeline[]
  updates                 TaskUpdate[]

  @@index([assignedToId])
  @@index([status])
  @@index([deadline])
}

model TaskTimeline {
  id        String   @id @default(uuid())
  taskId    String
  task      Task     @relation(fields: [taskId], references: [id], onDelete: Cascade)
  authorId  String?
  authorName String
  action    String
  note      String?
  timestamp DateTime @default(now())
}
```

---

## 5. Phased Migration & Cutover Strategy

```mermaid
flowchart LR
    Phase1["Phase 1:<br/>Database Provisioning &<br/>Prisma Definition"] --> Phase2["Phase 2:<br/>Historical Data ETL &<br/>Integrity Checksum"]
    Phase2 --> Phase3["Phase 3:<br/>Dual-Read Validation &<br/>Service Layer Abstraction"]
    Phase3 --> Phase4["Phase 4:<br/>Controlled Cutover<br/>(PostgreSQL Primary)"]
    Phase4 --> Phase5["Phase 5:<br/>MongoDB Decommissioning &<br/>Final Verification"]
```

### Phase 1: Database Provisioning & Prisma Configuration
- Provision production PostgreSQL 16 instance (AWS RDS, Neon, or Supabase).
- Install `@prisma/client` and `prisma` dev dependencies.
- Define initial Prisma schema preserving all foreign key relationships and unique indexes.
- Run `npx prisma db push` or `npx prisma migrate dev` to instantiate empty schemas.

### Phase 2: Historical Data ETL & Integrity Checksum
- Develop an idempotent, batched ETL script (`scripts/migrate-mongo-to-postgres.ts`).
- **Entity Ordering Sequence:**
  1. `Department`, `Holiday`, `AppSettings`, `SystemLock` (No foreign keys)
  2. `User` (Preserves `_id` as `mongoId`, maps to UUID)
  3. `Client`, `Equipment`
  4. `DeliveryEvent`, `ShootLog`, `ShootLogItem`
  5. `Task`, `TaskTimeline`, `TaskUpdate`, `TransferRequest`
  6. `WorkLog`, `LeaveRequest`
  7. `Conversation`, `Message`, `Call`, `Meeting`, `Notification`
- **Validation Engine:** Run record-by-record and aggregate hash checksum comparisons between MongoDB collections and PostgreSQL tables.

### Phase 3: Dual-Read & Service Layer Abstraction
- Create abstract repository interfaces (`IUserRepository`, `ITaskRepository`, etc.).
- Allow feature-flagged routing:
  - Write: Primary to MongoDB, shadow replicate to PostgreSQL.
  - Read: Validate matching results from PostgreSQL against MongoDB in background.

### Phase 4: Controlled Cutover
- Execute final delta synchronization of records created during Phase 3.
- Toggle primary connection to PostgreSQL.
- Maintain MongoDB in read-only standby for 14 days.

### Phase 5: MongoDB Decommissioning
- Verify zero inbound traffic or dependencies on MongoDB.
- Remove Mongoose dependency from `package.json`.
- Complete archive of historical MongoDB BSON dumps.

---

## 6. Rollback Procedures & Contingency Matrix

| Phase | Failure Trigger | Rollback Mechanism | Time to Recover | Data Impact |
|---|---|---|---|---|
| **Phase 2 (ETL)** | Data transformation failure or checksum mismatch | Abort script, truncate PostgreSQL tables, correct mapping logic, retry. | Immediate (< 5 min) | Zero impact on production MongoDB |
| **Phase 3 (Shadow Validation)** | Inconsistencies detected during shadow replication | Disable shadow replication flag; MongoDB remains sole source of truth. | Immediate (< 1 min) | Zero impact |
| **Phase 4 (Cutover)** | PostgreSQL latency spike or connection exhaustion | Revert `DATABASE_DRIVER` environment variable back to `mongodb`. | Immediate (< 2 min) | Delta records written to Postgres synced back via rollback script |
